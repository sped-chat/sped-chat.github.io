﻿window.siteConfig = {
    "identityGatewayBaseUri": "https://login.frontlineeducation.com/",
    "frontdoorUrl": "https://app.frontlineeducation.com/",
    "clientId": "idAccountSettings",
    "termsAndConditionsUrl": "https://login.frontlineeducation.com/ui/#/terms",
    "PlatformAnnouncementsBaseUri": "https://msvc-plat-announcements.use1.frontlineeducation.com",
    "featureActivator": {
        GoogleAnalyticsEnabled: true,
    },
    "enableProductMessages": [ "cc" ],
    "showRolesExternalIdp": [ "absmgmt","ta" ],
    "configCatEnvironmentKey": "V_7XCIkq50CKzPmiM0YU_A/VSadpU-w2kSpvTsADlOK1Q",
    "verifyEmailPollingInterval": 5000
};